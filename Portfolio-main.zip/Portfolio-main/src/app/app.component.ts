import { Component } from '@angular/core';
import { NavbarComponent }      from './components/navbar/navbar.component';
import { HeroComponent }        from './components/hero/hero.component';
import { AboutComponent }       from './components/about/about.component';
import { ExperienceComponent }  from './components/experience/experience.component';
import { ProjectsComponent }    from './components/projects/projects.component';
import { AchievementsComponent } from './components/achievements/achievements.component';
import { ContactComponent }     from './components/contact/contact.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    NavbarComponent,
    HeroComponent,
    AboutComponent,
    ExperienceComponent,
    ProjectsComponent,
    AchievementsComponent,
    ContactComponent
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {}

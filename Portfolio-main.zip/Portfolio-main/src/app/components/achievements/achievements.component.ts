import { Component, afterNextRender } from '@angular/core';

interface Achievement {
  rank:        string;
  title:       string;
  description: string;
  badge:       string;
  featured:    boolean;
}

@Component({
  selector: 'app-achievements',
  standalone: true,
  templateUrl: './achievements.component.html',
  styleUrl:    './achievements.component.scss'
})
export class AchievementsComponent {
  achievements: Achievement[] = [
    {
      rank:        '1st Place',
      title:       'CuseHacks Datathon 2026 — Image Classification',
      description: 'Trained EfficientNet-B3 via transfer learning achieving 92% validation accuracy across 102 classes at Syracuse University\'s premier datathon.',
      badge:       '🏆',
      featured:    true
    },
    {
      rank:        '1st Rank',
      title:       'State Level Engineering Project Competition — India',
      description: 'Recognized among 100+ competing teams for innovative system design, earning the top position at the State Level Engineering Project Competition.',
      badge:       '🥇',
      featured:    false
    },
    {
      rank:        '3rd Rank',
      title:       'State Level Hackathon — India',
      description: 'Delivered a working prototype within a 24-hour competitive development cycle, placing 3rd at the State Level Hackathon.',
      badge:       '🥉',
      featured:    false
    }
  ];

  constructor() {
    afterNextRender(() => this.initReveal());
  }

  private initReveal() {
    const obs = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('is-visible'); obs.unobserve(e.target); }
      }),
      { threshold: 0.1 }
    );
    document.querySelectorAll('#achievements .reveal').forEach(el => obs.observe(el));
  }
}

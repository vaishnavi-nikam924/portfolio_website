import { Component, afterNextRender, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-hero',
  standalone: true,
  templateUrl: './hero.component.html',
  styleUrl: './hero.component.scss'
})
export class HeroComponent {
  @ViewChild('heroSection') heroRef!: ElementRef;

  stats = [
    { value: '1+',   label: 'Year Professional Experience' },
    { value: '3.59', label: 'Graduate GPA at Syracuse'     },
    { value: '#1',   label: 'CuseHacks Datathon 2026'      },
  ];

  scrollToProjects(event: Event) {
    event.preventDefault();
    const el = document.querySelector('#projects');
    if (el) window.scrollTo({ top: (el as HTMLElement).offsetTop - 72, behavior: 'smooth' });
  }

  scrollToContact(event: Event) {
    event.preventDefault();
    const el = document.querySelector('#contact');
    if (el) window.scrollTo({ top: (el as HTMLElement).offsetTop - 72, behavior: 'smooth' });
  }
}

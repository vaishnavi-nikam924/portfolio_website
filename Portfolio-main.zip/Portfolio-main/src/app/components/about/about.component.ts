import { Component, afterNextRender } from '@angular/core';

interface SkillGroup {
  category: string;
  skills: string[];
}

@Component({
  selector: 'app-about',
  standalone: true,
  templateUrl: './about.component.html',
  styleUrl: './about.component.scss'
})
export class AboutComponent {
  skillGroups: SkillGroup[] = [
    {
      category: 'Frontend',
      skills: ['React.js', 'TypeScript', 'JavaScript', 'HTML5', 'CSS3', 'WCAG / Accessibility', 'Responsive Design', 'Angular']
    },
    {
      category: 'Backend & APIs',
      skills: ['.NET Core', 'Node.js', 'Express.js', 'REST APIs', 'Microservices', 'Spring Boot']
    },
    {
      category: 'AI & Machine Learning',
      skills: ['TensorFlow', 'PyTorch', 'Scikit-learn', 'Generative AI', 'LLM Integration', 'NLP', 'Computer Vision']
    },
    {
      category: 'Cloud & DevOps',
      skills: ['Microsoft Azure', 'AWS (S3, Lambda, Bedrock)', 'Docker', 'Jenkins', 'CI/CD', 'Azure DevOps']
    },
    {
      category: 'Databases',
      skills: ['PostgreSQL', 'MongoDB', 'MySQL', 'OracleDB', 'Firebase']
    },
    {
      category: 'Tools & Practices',
      skills: ['Git', 'Jest', 'Postman', 'Agile / Scrum', 'JIRA', 'Prompt Engineering', 'UML']
    }
  ];

  constructor() {
    afterNextRender(() => this.initReveal());
  }

  private initReveal() {
    const observer = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('is-visible'); observer.unobserve(e.target); }
      }),
      { threshold: 0.12 }
    );
    document.querySelectorAll('#about .reveal').forEach(el => observer.observe(el));
  }
}

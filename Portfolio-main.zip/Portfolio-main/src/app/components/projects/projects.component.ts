import { Component, afterNextRender } from '@angular/core';

export interface Project {
  title:       string;
  subtitle:    string;
  description: string;
  techStack:   string[];
  highlights:  string[];
  githubUrl:   string;
  liveUrl?:    string;
  accentFrom:  string;
  accentTo:    string;
  icon:        string;
}

@Component({
  selector: 'app-projects',
  standalone: true,
  templateUrl: './projects.component.html',
  styleUrl:    './projects.component.scss'
})
export class ProjectsComponent {
  projects: Project[] = [
    {
      title:       'InterviewIQ',
      subtitle:    'AI-Powered Interview Coaching System',
      description: 'A production-grade full-stack AI coaching platform delivering personalized interview questions and structured feedback across 8 roles and 3 difficulty tiers — with a fully accessible, cross-device React UI.',
      techStack:   ['.NET Core', 'React.js', 'JavaScript', 'HTML5/CSS3', 'REST APIs', 'Gemini 2.0 Flash', 'Docker', 'Railway', 'Vercel'],
      highlights: [
        'Architected .NET Core Minimal API with JSON prompt-engineering schemas for deterministic LLM output',
        'Containerized backend via Docker on Railway; React frontend provisioned on Vercel',
        'WCAG/ARIA accessible UI serving 8 interview roles × 3 difficulty tiers'
      ],
      githubUrl:  'https://github.com/Ompatil04/InterviewIQ',
      accentFrom: '#e11d48',
      accentTo:   '#be123c',
      icon:       '🎯'
    },
    {
      title:       'AgentPM',
      subtitle:    'Multi-Agent AI Productivity System',
      description: 'A multi-agent orchestration system where Planning and Reflection Agents invoke Llama 3 via Groq to generate memory-informed tasks, track progress, and deliver iterative productivity insights.',
      techStack:   ['React', 'JavaScript', 'Node.js', 'Express', 'Groq API', 'Llama 3', 'Multi-Agent Architecture'],
      highlights: [
        'Pioneered stateful inter-agent context passing — reflection insights feed back into planning prompts',
        'Strict JSON output schemas with RESTful Express.js API for maintainability & testability',
        'Real-time dashboard with goal tracking, task execution, and agent memory visualization'
      ],
      githubUrl:  'https://github.com/Ompatil04/AgentPM',
      accentFrom: '#334155',
      accentTo:   '#0f172a',
      icon:       '🤖'
    },
    {
      title:       'Personal Finance Tracker',
      subtitle:    'Full-Stack Finance Management App',
      description: 'A production-grade web application for managing financial accounts, tracking income and expenses, and visualizing spending patterns — built with a unique mixed Java + Kotlin Spring Boot architecture.',
      techStack:   ['Java 17', 'Kotlin', 'Spring Boot 3', 'Spring MVC', 'Spring Data JPA', 'Hibernate', 'Thymeleaf', 'Bootstrap 5', 'H2'],
      highlights: [
        'Mixed Java + Kotlin architecture: Java services/models with a Kotlin MVC controller layer',
        'JPA entity relationships (User → Account → Transaction) with real-time balance tracking',
        'Category-based expense aggregation with visual progress bars across a dark Bootstrap dashboard'
      ],
      githubUrl:  'https://github.com/Ompatil04',
      accentFrom: '#475569',
      accentTo:   '#1e293b',
      icon:       '💰'
    }
  ];

  constructor() {
    afterNextRender(() => this.initReveal());
  }

  private initReveal() {
    const obs = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('is-visible'); obs.unobserve(e.target); }
      }),
      { threshold: 0.08 }
    );
    document.querySelectorAll('#projects .reveal').forEach(el => obs.observe(el));
  }
}

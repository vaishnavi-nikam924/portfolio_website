import { Component, afterNextRender } from '@angular/core';

@Component({
  selector: 'app-contact',
  standalone: true,
  templateUrl: './contact.component.html',
  styleUrl:    './contact.component.scss'
})
export class ContactComponent {
  currentYear = new Date().getFullYear();

  contacts = [
    {
      label:    'Email',
      value:    'omnitinpatil.cs@gmail.com',
      href:     'mailto:omnitinpatil.cs@gmail.com',
      icon:     'email'
    },
    {
      label:    'LinkedIn',
      value:    'linkedin.com/in/ompatil04',
      href:     'https://linkedin.com/in/ompatil04',
      icon:     'linkedin'
    },
    {
      label:    'GitHub',
      value:    'github.com/Ompatil04',
      href:     'https://github.com/Ompatil04',
      icon:     'github'
    },
    {
      label:    'Location',
      value:    'Syracuse, NY',
      href:     null,
      icon:     'location'
    }
  ];

  constructor() {
    afterNextRender(() => this.initReveal());
  }

  private initReveal() {
    const obs = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('is-visible'); obs.unobserve(e.target); }
      }),
      { threshold: 0.1 }
    );
    document.querySelectorAll('#contact .reveal').forEach(el => obs.observe(el));
  }
}

import { Component, HostListener, signal } from '@angular/core';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [NgClass],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent {
  scrolled   = signal(false);
  menuOpen   = signal(false);

  navLinks = [
    { label: 'About',        href: '#about'        },
    { label: 'Experience',   href: '#experience'   },
    { label: 'Projects',     href: '#projects'     },
    { label: 'Achievements', href: '#achievements' },
    { label: 'Contact',      href: '#contact'      },
  ];

  @HostListener('window:scroll')
  onScroll() {
    this.scrolled.set(window.scrollY > 40);
  }

  toggleMenu() {
    this.menuOpen.update(v => !v);
  }

  closeMenu() {
    this.menuOpen.set(false);
  }

  scrollTo(id: string, event: Event) {
    event.preventDefault();
    this.closeMenu();
    const el = document.querySelector(id);
    if (el) {
      const top = (el as HTMLElement).offsetTop - 72;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  }
}

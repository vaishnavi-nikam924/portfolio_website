import { Component, afterNextRender } from '@angular/core';

interface ExperienceItem {
  role:        string;
  company:     string;
  location:    string;
  period:      string;
  current:     boolean;
  techStack:   string[];
  bullets:     string[];
}

@Component({
  selector: 'app-experience',
  standalone: true,
  templateUrl: './experience.component.html',
  styleUrl: './experience.component.scss'
})
export class ExperienceComponent {
  experiences: ExperienceItem[] = [
    {
      role:     'Software Engineer',
      company:  'Burns & McDonnell',
      location: 'India',
      period:   'Jun 2023 – Jul 2024',
      current:  false,
      techStack: ['React.js', 'TypeScript', '.NET Core', 'Azure DevOps', 'REST APIs', 'OAuth 2.0'],
      bullets: [
        'Designed and shipped end-to-end React.js / TypeScript front-end features with accessible, responsive UI components (WCAG), improving user task completion across self-service workflows.',
        'Overhauled scalable backend services using .NET Core, boosting system throughput by 40% via connection pooling and asynchronous processing patterns.',
        'Implemented identity-aware OAuth 2.0 authentication and granular RBAC, securing user access workflows and cutting unauthorized access incidents by 40%.',
        'Accelerated release velocity by 25% through end-to-end Azure DevOps CI/CD pipeline automation, eliminating manual deployment steps across staging and production.',
        'Authored unit and integration tests (Jest, Postman) validating REST API endpoints and front-end component behavior, reducing regression defects in production.',
        'Spearheaded migration to Telerik Reporting, improving data accuracy while mentoring 3 junior developers.'
      ]
    }
  ];

  constructor() {
    afterNextRender(() => this.initReveal());
  }

  private initReveal() {
    const obs = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('is-visible'); obs.unobserve(e.target); }
      }),
      { threshold: 0.08 }
    );
    document.querySelectorAll('#experience .reveal').forEach(el => obs.observe(el));
  }
}
